# SparkVisuals 0.3.0 — Main Menu Prototype

Android Studio project (Java, Android Gradle Plugin 8.7.3, JDK 17).

## Included
- Main SparkVisuals menu using the exact logo supplied by the user.
- Dark glass-inspired cards with cyan accents.
- Switches for HUD, FPS/CPS, coordinates, Target HUD, crosshair, Zoom, animations.
- Spark Helper settings: Sugar 10-block radius, Eye of Ender 10-block radius, Netherite Scrap trap area 4x3 symmetric from player feet.
- Projectile prediction toggles: Snowball with 4x4 final zone, bow/arrow, crossbow, trident, ender pearl.
- Settings persist locally via SharedPreferences.
- Dynamic Island overlay prototype with logo and FPS/Ping placeholder labels.

## Important
This is a menu and UI prototype only. Switches currently save preferences locally; they do not activate Minecraft game features. FPS/Ping are placeholders, not live telemetry. No game injection, memory reading, anti-cheat bypass, or Minecraft asset redistribution is included. Compatibility with Minecraft 1.26.50.4 and native ABI still needs independent verification.

## Build
Open the project folder in Android Studio using JDK 17, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).
For Dynamic Island, grant the app Android's “Display over other apps” permission.


## Build from a phone (cloud build)
This project includes `.github/workflows/android-apk.yml`.
1. Create a GitHub repository and upload the **contents** of this project folder.
2. Open the repository's Actions tab.
3. Select "Build SparkVisuals APK" and tap "Run workflow".
4. When the run completes, open it and download the `SparkVisuals-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

The cloud build requires a GitHub account and internet access. The generated debug APK is unsigned for Play Store release, but can normally be installed manually after enabling permission to install apps from that source.
