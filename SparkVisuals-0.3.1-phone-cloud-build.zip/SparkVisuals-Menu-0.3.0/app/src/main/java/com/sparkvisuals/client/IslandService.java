package com.sparkvisuals.client;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
import android.graphics.Typeface;

public class IslandService extends Service {
    private WindowManager wm; private View island; private WindowManager.LayoutParams params;
    @Override public void onCreate() {
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout pill=new LinearLayout(this); pill.setOrientation(0); pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(12,7,16,7);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.argb(238,10,16,27));
        bg.setCornerRadius(60); bg.setStroke(2,Color.rgb(49,176,235)); pill.setBackground(bg);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.spark_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(34,34); lp.rightMargin=12; pill.addView(logo,lp);
        pill.addView(metric("FPS  --"));
        View gap=new View(this); pill.addView(gap,new LinearLayout.LayoutParams(14,1));
        pill.addView(metric("PING  -- ms"));
        params=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL; params.y=34;
        pill.setOnTouchListener(new View.OnTouchListener(){
            int sx,sy; float dx,dy;
            public boolean onTouch(View v, android.view.MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=params.x;sy=params.y;dx=e.getRawX();dy=e.getRawY();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=sx+(int)(e.getRawX()-dx);params.y=sy+(int)(e.getRawY()-dy);wm.updateViewLayout(island,params);return true;}
                return true;
            }});
        island=pill; wm.addView(island,params);
    }
    private TextView metric(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(12);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    @Override public void onDestroy(){if(wm!=null&&island!=null)wm.removeView(island);island=null;super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
