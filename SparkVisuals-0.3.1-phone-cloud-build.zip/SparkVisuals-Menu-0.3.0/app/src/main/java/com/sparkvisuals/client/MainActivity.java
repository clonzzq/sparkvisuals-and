package com.sparkvisuals.client;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8,13,22);
    private final int CARD = Color.rgb(17,25,39);
    private final int CYAN = Color.rgb(67,201,255);
    private final int WHITE = Color.rgb(239,245,252);
    private final int MUTED = Color.rgb(145,162,183);
    private LinearLayout root, content;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("spark_settings", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        buildHeader();
        buildIslandCard();
        buildSection("HUD MODULES", "Игровая информация");
        addToggle("Custom HUD", "Настраиваемая панель игровых показателей", "hud", true);
        addToggle("FPS Counter", "Счётчик кадров в секунду", "fps", true);
        addToggle("CPS Counter", "Подсчёт кликов в секунду", "cps", true);
        addToggle("Coordinates", "Координаты игрока XYZ", "coords", true);
        addToggle("Target HUD", "Информация о выбранной цели", "target", false);
        addToggle("Custom Crosshair", "Настраиваемый прицел", "crosshair", true);
        addToggle("Zoom", "Экранное приближение", "zoom", false);
        addToggle("Animations", "Визуальные анимации интерфейса", "animations", true);

        buildSection("SPARK HELPER", "Радиусы считаются от уровня ног игрока");
        addToggle("Sugar • 10 blocks", "Область обнаружения сахара: радиус 10 блоков", "sugar", false);
        addToggle("Eye of Ender • 10 blocks", "Область обнаружения ока Эндера: радиус 10 блоков", "eye", false);
        addToggle("Trap Zone • 4 × 3", "Незеритовый лом • 4 блока шириной × 3 высотой, симметрично", "trap", false);

        buildSection("PROJECTILE PREDICTION", "Предпросмотр траекторий");
        addToggle("Snowball • 4 × 4", "Траектория снежка и конечная зона 4 × 4 блока", "snowball", false);
        addToggle("Arrow / Bow", "Предсказание траектории стрелы", "arrow", false);
        addToggle("Crossbow", "Предсказание снаряда арбалета", "crossbow", false);
        addToggle("Trident", "Предсказание траектории трезубца", "trident", false);
        addToggle("Ender Pearl", "Предсказание места приземления жемчуга", "pearl", false);

        buildSection("CLIENT", "Информация о проекте");
        TextView version = text("SparkVisuals  •  v0.3.0\\nMinecraft target: 1.26.50.4\\nPackage: com.mojang.minecraftpe", 13, MUTED);
        version.setPadding(dp(4), dp(4), dp(4), dp(12));
        content.addView(version);

        TextView note = text("Важно: это меню и переключатели настроек. Они сохраняются на устройстве, но пока не управляют игровым движком Minecraft. Реальные FPS, Ping, HUD и предсказания требуют отдельной совместимой интеграции.", 12, MUTED);
        note.setPadding(dp(14), dp(12), dp(14), dp(12));
        note.setBackground(round(CARD, 16, 0, Color.TRANSPARENT));
        content.addView(note);

        setContentView(root);
    }

    private void buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.spark_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(12), 0, 0, 0);
        labels.addView(text("SPARKVISUALS", 22, WHITE, true));
        labels.addView(text("PVP VISUAL CLIENT", 10, CYAN, true));
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView tag = text("BETA", 11, CYAN, true);
        tag.setPadding(dp(12), dp(7), dp(12), dp(7));
        tag.setBackground(round(Color.rgb(15,48,67), 30, 1, Color.rgb(32,116,153)));
        row.addView(tag);
        content.addView(row);
        TextView subtitle = text("ТВОЙ ИНТЕРФЕЙС. ТВОИ ПРАВИЛА.", 11, MUTED, true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(10); p.bottomMargin = dp(18);
        content.addView(subtitle, p);
    }

    private void buildIslandCard() {
        LinearLayout card = card();
        card.addView(text("DYNAMIC ISLAND", 13, CYAN, true));
        TextView desc = text("Логотип SparkVisuals • FPS • Ping", 14, WHITE);
        LinearLayout.LayoutParams d = new LinearLayout.LayoutParams(-1, -2);
        d.topMargin = dp(7);
        card.addView(desc, d);
        Button btn = new Button(this);
        btn.setText("Включить плавающую панель");
        btn.setTextColor(Color.WHITE);
        btn.setBackground(round(Color.rgb(20,105,145), 14, 0, Color.TRANSPARENT));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(48));
        bp.topMargin = dp(12);
        card.addView(btn, bp);
        btn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            } else {
                startService(new Intent(this, IslandService.class));
                Toast.makeText(this, "Панель включена", Toast.LENGTH_SHORT).show();
            }
        });
        content.addView(card);
    }

    private void buildSection(String name, String subtitle) {
        TextView h = text(name, 12, CYAN, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(24); hp.bottomMargin = dp(5);
        content.addView(h, hp);
        TextView s = text(subtitle, 12, MUTED);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(10);
        content.addView(s, sp);
    }

    private void addToggle(String title, String desc, String key, boolean initial) {
        LinearLayout card = card();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(title, 15, WHITE, true));
        TextView detail = text(desc, 11, MUTED);
        detail.setPadding(0, dp(4), 0, 0);
        labels.addView(detail);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setButtonTintList(null);
        sw.setChecked(prefs.getBoolean(key, initial));
        sw.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean(key, checked).apply());
        row.addView(sw);
        card.addView(row);
        content.addView(card);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(14), dp(15), dp(14));
        c.setBackground(round(CARD, 17, 1, Color.rgb(34,49,68)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8);
        c.setLayoutParams(p);
        return c;
    }

    private TextView text(String value, int size, int color) { return text(value,size,color,false); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable round(int color, int radius, int stroke, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke > 0) d.setStroke(dp(stroke), strokeColor);
        return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
